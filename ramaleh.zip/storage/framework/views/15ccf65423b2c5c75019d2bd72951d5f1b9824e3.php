<?php echo e($data->get('message')); ?>

