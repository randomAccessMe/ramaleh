<section class="footer">

    <div class="logo"><img src="img/logo-footer.png"></div>
    <div class="menu-footer">

        <a href="#home">Home</a>
        <a href="https://www.facebook.com/ramaleh">Facebook</a>
        <a href="https://www.linkedin.com/in/rami-al-maleh-81b22b91">Linked In</a>
        <a href="https://github.com/randomAccessMe">Github</a>
        <a href="#contact">Contact</a>

    </div>

    <div class="copyright">© 2016. All Rights Reserved {{ env('APP_DOMAIN', 'Ramaleh.com') }}</div>


</section>