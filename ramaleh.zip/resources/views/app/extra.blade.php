<section class="partners parallax-background-partners" id="partners">

    <div class="opacity"></div>

    <div class="content">

        <div class="logo buffer-lg-top">

            <a href="https://www.facebook.com/ramaleh">
                <img src="img/logos/1464743648_facebook2.png">
            </a>
            <a href="https://www.linkedin.com/in/rami-al-maleh-81b22b91">
                <img src="img/logos/1464743655_linkedin2.png">
            </a>
            <a href="#contact">
                <img src="img/logos/1464743675_Outlook.png">
            </a>
            <a href="#">
                <script type="text/javascript" src="https://secure.skypeassets.com/i/scom/js/skype-uri.js"></script>
                <img src="img/logos/1464743695_skype.png" id="SkypeButton_Call_ramaleh91_1">
                    <script type="text/javascript">
                        Skype.ui({
                            "name": "chat",
                            "element": "SkypeButton_Call_ramaleh91_1",
                            "participants": ["ramaleh91"],
                            "imageColor": "white",
                            "imageSize": 32
                        });
                    </script>
            </a>
            <a href="https://github.com/randomAccessMe">
                <img src="img/logos/1464743722_github.png">
            </a>

        </div>

    </div>

</section>